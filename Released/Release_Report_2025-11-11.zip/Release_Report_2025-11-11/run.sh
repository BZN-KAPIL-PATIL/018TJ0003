#!/bin/bash
cd /home/bznpwrusr/Desktop/Daily_Work/October/31/Release_Report_2025-10-31
java -jar ElectroSteel_Ind.jar




